import java.util.HashMap;
import java.util.Random;

public class GrafoDirigidoAciclico<T> {
    private int[][] matrizDeAdyacencia;
    private HashMap<Integer,ListaSimple<T>> listaDeAdyacencia = null;
    private int numeroDeNodos;
    private T[] vertices;
    private boolean esDeEnteros;


    //Constructor para 0 a n-1
    public GrafoDirigidoAciclico(int n) {
        this.numeroDeNodos = n;
        this.matrizDeAdyacencia = new int[n][n];
        this.listaDeAdyacencia = new HashMap<>();
        this.esDeEnteros = true;
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                this.matrizDeAdyacencia[i][j] = 0;
            }
        }
        for (int i = 0; i < n; i++){
            listaDeAdyacencia.put(i, new ListaSimple<>());
        }

        this.vertices = (T[]) new Object[n];

        for (int i = 0; i < n; i++) {
            vertices[i] = (T) Integer.valueOf(i);
        }

    }

    //Constructor para 4 numeros aleatorios
    public GrafoDirigidoAciclico() {
        Random random = new Random();
        numeroDeNodos = 4;
        matrizDeAdyacencia = new int[numeroDeNodos][numeroDeNodos];
        this.vertices = (T[]) new Object[numeroDeNodos];
        this.esDeEnteros = true;

        for (int i = 0; i < numeroDeNodos; i++) {
            int aleatorio = new Random().nextInt(100);
            vertices[i] = (T) Integer.valueOf(aleatorio);
        }
        vertices[0] =(T) Integer.valueOf(15);
        vertices[1] =(T) Integer.valueOf(20);
        vertices[2] =(T) Integer.valueOf(30);
        vertices[3] =(T) Integer.valueOf(10);
        this.listaDeAdyacencia = new HashMap<>();
        for (int i = 0; i < numeroDeNodos; i++) {
            for (int j = 0; j < numeroDeNodos; j++) {
                this.matrizDeAdyacencia[i][j] = 0;
            }
        }
        for (int i = 0; i < numeroDeNodos; i++){
            listaDeAdyacencia.put(i, new ListaSimple<>());
        }

    }

    //Constructor para utilizar letras
    public GrafoDirigidoAciclico(T[] vertices) {
        this.numeroDeNodos = vertices.length;
        this.matrizDeAdyacencia = new int[numeroDeNodos][numeroDeNodos];
        this.listaDeAdyacencia = new HashMap<>();
        this.esDeEnteros = false;

        // Inicializar la matriz de adyacencia con ceros
        for (int i = 0; i < numeroDeNodos; i++) {
            for (int j = 0; j < numeroDeNodos; j++) {
                this.matrizDeAdyacencia[i][j] = 0;
            }
        }

        // Inicializar la lista de adyacencia
        for (int i = 0; i < numeroDeNodos; i++) {
            listaDeAdyacencia.put(i, new ListaSimple<>());
        }

        this.vertices = (T[]) new Object[numeroDeNodos];
        for (int i = 0; i < numeroDeNodos; i++) {
            this.vertices[i] = vertices[i];
        }
    }

    //Metodo para conectaar dos vertices
    public boolean insertarArista(T origen, T destino) {
        // Encontrar los índices correspondientes
        int i = obtenerIndice(origen);
        int j = obtenerIndice(destino);

        if (i == -1 || j == -1) {
            System.out.println("Uno o ambos vertices no existen en el grafo.");
            return false;
        }

        if (i == j) {
            System.out.println("No se permiten bucles");
            return false;
        }

        if (tieneCiclos(origen, destino)) {
            System.out.println("No se puede agregar la arista: " + origen + " y " + destino);
            return false;
        }
        matrizDeAdyacencia[i][j] = 1;
        ListaSimple<T> conexion = listaDeAdyacencia.get(i);
        conexion.insertaFin(destino);
        listaDeAdyacencia.put(i, conexion);

        return true;
    }


    /*
     * Metodo auxiliar para distintos metodos, este tendra
     * el objetivo de encontrar el indice en el que se encuentra X elemento
     * en nuesto arreglo de vertices
     */
    private int obtenerIndice(T vertice) {
        for (int k = 0; k < vertices.length; k++) {
            if (vertices[k].equals(vertice)) {
                return k;
            }
        }
        return -1;
    }


    //Metodo para validar que el grafo sea aciclico
    public boolean tieneCiclos(T origen, T destino) {
        int i = obtenerIndice(origen);
        int j = obtenerIndice(destino);
        if (i == -1 || j == -1) {
            System.out.println("Uno o ambos vertices no existen en el grafo.");
            return false;
        }
        return conectado(origen, destino);
    }


    //Merodo para eliminar todas las conexiones
    public void eliminarAristas() {
        for (int i = 0; i < numeroDeNodos; i++) {
            listaDeAdyacencia.put(i, new ListaSimple<>());
            for (int j = 0; j < numeroDeNodos; j++) {
                matrizDeAdyacencia[i][j] = 0;
            }
        }
    }


    //Metodo para imprimir la lista de adyacencia
    public void imprimirListaAdyacencia() {
        listaDeAdyacencia.forEach((indice, conexiones) -> {
            T vertice = vertices[indice];
            System.out.println(vertice + ": " + conexiones.imprimir());
        });
    }


    //Metodo que regresa la matriz de adyacencia
    public String mostrarEstructura() {
        StringBuilder sb = new StringBuilder();
        sb.append("  ");
        for (T vertice : vertices) {
            sb.append(vertice).append(" ");
        }
        sb.append("\n");
        for (int i = 0; i < numeroDeNodos; i++) {
            sb.append(vertices[i]).append(" ");
            for (int j = 0; j < numeroDeNodos; j++) {
                sb.append(matrizDeAdyacencia[i][j]).append(" ");
            }
            sb.append("\n");
        }
        return sb.toString();
    }


    //Metodo para encontrar el grado de entrada
    public int gradoDeEntrada(T vertice) {
        int i = obtenerIndice(vertice);
        if (i == -1) {
            System.out.println("Vertice no valido: " + vertice);
            return -1;
        }
        int gradoDeEntrada = 0;
        for (int j = 0; j < numeroDeNodos; j++) {
            if (matrizDeAdyacencia[j][i] == 1) {
                gradoDeEntrada++;
            }
        }
        return gradoDeEntrada;
    }


    //Metodo para encontrar el grado de salida
    public int gradoDeSalida(T vertice) {
        int i = obtenerIndice(vertice);
        if (i == -1) {
            System.out.println("Vertice no valido: " + vertice);
            return -1;
        }
        int gradoDeSalida = 0;
        for (int j = 0; j < numeroDeNodos; j++) {
            if (matrizDeAdyacencia[i][j] == 1) {
                gradoDeSalida++;
            }
        }
        return gradoDeSalida;
    }


    //Metodo para obtner el numerto total de aristas
    public int cuantasAristasHay(){
        int aristas = 0;
        for (int i = 0; i < numeroDeNodos; i++){
            for (int j = 0; j < numeroDeNodos; j++){
                if (matrizDeAdyacencia[i][j] == 1){
                    aristas++;
                }
            }
        }
        return aristas;
    }


    //Metodo para saber si un vertice es adyacente a otro
    public boolean adyacente(T origen, T destino) {
        int indiceOrigen = obtenerIndice(origen);
        int indiceDestino = obtenerIndice(destino);
        if (indiceOrigen == -1 || indiceDestino == -1) {
            System.out.println("Vertices invalidos: " + origen + " o " + destino);
            return false;
        }
        return matrizDeAdyacencia[indiceOrigen][indiceDestino] == 1;
    }


    //Metodo para saber si un vertice esta conectado a otro
    public boolean conectado(T inicio, T destino) {
        boolean[] visitados = new boolean[numeroDeNodos];
        ColaSimple<T> cola = new ColaSimple<>();

        int indiceInicio = obtenerIndice(inicio);
        int indiceDestino = obtenerIndice(destino);

        if (indiceInicio == -1 || indiceDestino == -1) {
            System.out.println("Vertices invalidos: " + inicio + " o " + destino);
            return false;
        }
        cola.insertar(inicio);
        visitados[indiceInicio] = true;
        while (!cola.esVacio()) {
            T nodoActual = cola.eliminar();
            int indiceActual = obtenerIndice(nodoActual);

            if (indiceActual == indiceDestino) {
                return true;
            }

            for (int adyacente = 0; adyacente < numeroDeNodos; adyacente++) {
                if (matrizDeAdyacencia[indiceActual][adyacente] == 1 && !visitados[adyacente]) {
                    cola.insertar(vertices[adyacente]);
                    visitados[adyacente] = true;
                }
            }
        }
        return false;
    }


    public String topologicalSort() {
        int[] gradoDeEntrada = new int[numeroDeNodos];

        for (int i = 0; i < numeroDeNodos; i++) {
            gradoDeEntrada[i] = gradoDeEntrada(vertices[i]);
        }

        StringBuilder ordenTopologico = new StringBuilder();

        for (int k = 0; k < numeroDeNodos; k++) {
            int nodoConPrioridad = -1;
            for (int i = 0; i < numeroDeNodos; i++) {
                if (gradoDeEntrada[i] == 0) {
                    nodoConPrioridad = i;
                    gradoDeEntrada[i] = -1;
                    break;
                }
            }

            if (nodoConPrioridad == -1) {
                throw new IllegalStateException("El grafo tiene un ciclo");
            }
            if (esDeEnteros) {
                ordenTopologico.append(nodoConPrioridad).append("-");
            } else {
                ordenTopologico.append((char)(nodoConPrioridad + 65)).append("-");
            }
            for (int j = 0; j < numeroDeNodos; j++) {
                if (matrizDeAdyacencia[nodoConPrioridad][j] == 1) {
                    gradoDeEntrada[j]--;
                }
            }
        }
        ordenTopologico.deleteCharAt(ordenTopologico.length() - 1);
        return ordenTopologico.toString();
    }

}
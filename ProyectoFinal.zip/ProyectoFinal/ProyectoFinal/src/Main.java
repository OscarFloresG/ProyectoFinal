public class Main {
    public static void main(String[] args) {
        GrafoDirigidoAciclico grafo = new GrafoDirigidoAciclico(5);
        grafo.insertarArista(1,3);
        grafo.insertarArista(1,4);
        grafo.insertarArista(2,3);
        grafo.insertarArista(2,4);
        grafo.insertarArista(3,2);
        grafo.insertarArista(3,4);
        System.out.println(grafo.mostrarEstructura());
        grafo.imprimirListaAdyacencia();

    }

}
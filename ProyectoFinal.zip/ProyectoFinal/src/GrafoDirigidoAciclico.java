import java.util.HashMap;
import java.util.Random;

public class GrafoDirigidoAciclico<T> {
    private int[][] matrizDeAdyacencia;
    //private ListaSimple<ListaSimple<Integer>> listaDeAdyacencia;
    private HashMap<Integer,ListaSimple<T>> listaDeAdyacencia = null;
    private int numeroDeNodos;
    private int[] vertices;
    //private boolean nomenclatura;

    public GrafoDirigidoAciclico(int n) {
        this.numeroDeNodos = n;
        this.matrizDeAdyacencia = new int[n][n];
        this.listaDeAdyacencia = new HashMap<>();
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                this.matrizDeAdyacencia[i][j] = 0;
            }
        }
        for (int i = 0; i < n; i++){
            listaDeAdyacencia.put(i, new ListaSimple<>());
        }

       /* this.listaDeAdyacencia = new ListaSimple<>();
        for (int i = 0; i < n; i++) {
            listaDeAdyacencia.insertaFin(new ListaSimple<>());
        }*/
    }

    public GrafoDirigidoAciclico() {
        new Random().nextInt(100);
        numeroDeNodos = 4;
    }

    /*public boolean insertarArista(int i, int j){
        boolean aristaValida = false;

        if (i != j) {
            if (i > numeroDeNodos || j > numeroDeNodos) {
                //aristaValida = false;
                throw new ArrayIndexOutOfBoundsException("Índice fuera de rango");
            } else {
                if (matrizDeAdyacencia[i][j] == 0) {
                    matrizDeAdyacencia[i][j] = 1;
                    aristaValida = true;
                } else {
                    aristaValida = false;
                }
            }
        }


        return aristaValida;
    }*/

    public boolean insertarArista(int i, int j) {
        boolean aristaValida = false;

        if (i != j) {  // Verificamos que los nodos son distintos
            if (i >= 0 && i < numeroDeNodos && j >= 0 && j < numeroDeNodos) {
                // Índices válidos, insertamos la arista
                if (matrizDeAdyacencia[i][j] == 0) {
                    matrizDeAdyacencia[i][j] = 1;
                    aristaValida = true;
                } else {
                    aristaValida = false; // La arista ya existe
                }
            } else {
                // Índices fuera de rango, no se inserta la arista
                aristaValida = false;
                System.out.println("Indices fuera de rango. ");
            }
        }

        //INSERTAR AHORA EN LA LISTA DE ADYACENCIA
        if (aristaValida) {
            T dato = (T) Integer.valueOf(j);
            ListaSimple<T> conexion = listaDeAdyacencia.get(i);
            conexion.insertaFin(dato);
            conexion.ordenarLista();
            listaDeAdyacencia.put(i,conexion);
        }
        return aristaValida;

    }

    public void eliminarAristas(){
        ListaSimple lista = new ListaSimple<>();
        for (int i = 0; i < numeroDeNodos; i++) {
            listaDeAdyacencia.put(i, lista);
            for (int j = 0; j < numeroDeNodos; j++) {
                matrizDeAdyacencia[i][j] = 0;
            }
        }
        //lista.eliminarTodo();
    }

    public int[][] getMatrizDeAdyacencia() {
        return matrizDeAdyacencia;
    }

    /*public void imprimirListaAdyacencia(){
        for (Map.Entry<Integer, ListaSimple<T>> entry : listaDeAdyacencia.entrySet()){
            System.out.print(entry.getKey() + entry.getValue().imprimir());
            System.out.println();
        }
    }*/

    public void imprimirListaAdyacencia() {
        listaDeAdyacencia.forEach((nodo, conexiones) ->
                System.out.println(nodo + conexiones.imprimir()));
    }


    public void imprimirMatriz(){
        for (int i = 0; i < numeroDeNodos; i++) {
            for (int j = 0; j < numeroDeNodos; j++) {
                System.out.print(matrizDeAdyacencia[i][j] + " ");
            }
            System.out.println();
        }
    }

    public int gradoDeEntrada(int i){
        int gradoDeEntrada = 0;

        if (i < 0 || i >= numeroDeNodos) {
            System.out.println("Indice invalido: " + i);
            return -1; // Devuelve un valor especial para indicar error
        }

        for(int j = 0 ; j < numeroDeNodos ; j++){
            if (matrizDeAdyacencia[j][i] == 1){
                gradoDeEntrada++;
            }
        }
        return gradoDeEntrada;
    }

    public int gradoDeSalida(int i){
        int gradoDeSalida = 0;

        if (i < 0 || i >= numeroDeNodos) {
            System.out.println("Indice invalido: " + i);
            return -1; // Devuelve un valor especial para indicar error
        }

        for(int j = 0 ; j < numeroDeNodos ; j++){
            if (matrizDeAdyacencia[i][j] == 1){
                gradoDeSalida++;
            }
        }
        return gradoDeSalida;
    }

    public int cuantasAristasHay(){
        int aristas = 0;

        for (int i = 0; i < numeroDeNodos; i++){
            for (int j = 0; j < numeroDeNodos; j++){
                if (matrizDeAdyacencia[i][j] == 1){
                    aristas++;
                }
            }
        }
        return aristas;
    }

    public boolean adyacente(int i, int j){
        boolean adyacente = false;

        if (i < 0 || i >= numeroDeNodos || j < 0 || j >= numeroDeNodos) {
            System.out.println("Indices invalidos");
            return false;
        }


        if (matrizDeAdyacencia[i][j] == 1){
            adyacente = true;
        }

        return adyacente;
    }
    

    /*public void setMatrizDeAdyacencia(int[][] matrizDeAdyacencia) {
        this.matrizDeAdyacencia = matrizDeAdyacencia;
    }*/

    /*public ListaSimple<ListaSimple<Integer>> getListaDeAdyacencia() {
        return listaDeAdyacencia;
    }

    public void setListaDeAdyacencia(ListaSimple<ListaSimple<Integer>> listaDeAdyacencia) {
        this.listaDeAdyacencia = listaDeAdyacencia;
    }*/

    /*public int getNumeroDeNodos() {
        return numeroDeNodos;
    }

    public void setNumeroDeNodos(int numeroDeNodos) {
        this.numeroDeNodos = numeroDeNodos;
    }*/
}

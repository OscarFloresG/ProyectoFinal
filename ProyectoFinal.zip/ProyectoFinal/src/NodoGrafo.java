public class NodoGrafo<T> {
    private T info;
    private NodoGrafo[] siguientes;

}

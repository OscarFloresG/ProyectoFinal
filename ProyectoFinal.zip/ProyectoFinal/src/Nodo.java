public class Nodo<T> {

    private T info;
    private Nodo sig;

    public Nodo(){

    }

    public Nodo(T info, Nodo sig){
        this.info = info;
        this.sig = sig;
    }

    public T getInfo(){
        return info;
    }

    public void setInfo(T info){
        this.info = info;
    }

    public Nodo getSig(){
        return sig;
    }

    public void setSig(Nodo sig){
        this.sig = sig;
    }

    @Override
    public String toString() {
        return "Nodo{" +
                "info=" + info +
                ", sig=" + sig +
                '}';
    }
}
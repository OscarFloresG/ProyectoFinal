public class Main {
    public static void main(String[] args) {
        GrafoDirigidoAciclico grafo = new GrafoDirigidoAciclico(5);
        grafo.insertarArista(1,3);
        grafo.insertarArista(1,4);
        grafo.insertarArista(1,2);
        //boolean algo = grafo.insertarArista(3,5);
        //System.out.println(algo);
        grafo.imprimirMatriz();
        //grafo.eliminarAristas();
        //System.out.println();
       // grafo.imprimirMatriz();
        grafo.imprimirListaAdyacencia();

    }
}
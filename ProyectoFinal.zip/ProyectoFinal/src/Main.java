public class Main {
    public static void main(String[] args) {
        GrafoDirigidoAciclico grafo = new GrafoDirigidoAciclico(5);
        grafo.insertarArista(1,3);
        grafo.insertarArista(1,4);
        grafo.insertarArista(1,2);
        grafo.insertarArista(2,3);
        grafo.insertarArista(2,4);
        grafo.insertarArista(3,2);
        grafo.insertarArista(3,4);
        grafo.insertarArista(0,3);
        grafo.insertarArista(0,2);
        grafo.insertarArista(0,1);
        grafo.insertarArista(4,3);
        grafo.insertarArista(4,2);
        grafo.insertarArista(4,1);
        //grafo.insertarArista(4,5);
        //boolean algo = grafo.insertarArista(3,5);
        //System.out.println(algo);
        grafo.imprimirMatriz();
        //grafo.eliminarAristas();
        //System.out.println();
       // grafo.imprimirMatriz();
//        grafo.imprimirListaAdyacencia();
//        System.out.println();
//        grafo.eliminarAristas();
//        grafo.imprimirMatriz();
//        grafo.imprimirListaAdyacencia();
//        System.out.println(grafo.gradoDeEntrada(0));
//        System.out.println(grafo.gradoDeEntrada(1));
//        System.out.println(grafo.gradoDeEntrada(2));
//        System.out.println(grafo.gradoDeEntrada(3));
//        System.out.println(grafo.gradoDeEntrada(4));
//        System.out.println(grafo.gradoDeEntrada(5));

//        System.out.println(grafo.gradoDeSalida(0));
//        System.out.println(grafo.gradoDeSalida(1));
//        System.out.println(grafo.gradoDeSalida(2));
//        System.out.println(grafo.gradoDeSalida(3));
//        System.out.println(grafo.gradoDeSalida(4));
//        System.out.println(grafo.gradoDeSalida(5));
//        System.out.println(grafo.gradoDeSalida(-1));
        //System.out.println(grafo.cuantasAristasHay());
        System.out.println(grafo.adyacente(0,1));
        System.out.println(grafo.adyacente(0,2));
        System.out.println(grafo.adyacente(0,4));
        System.out.println(grafo.adyacente(3,0));
        System.out.println(grafo.adyacente(0,5));
        System.out.println(grafo.adyacente(5,5));



    }
}
public class ListaSimple <T> {

    private Nodo<T> inicio;

    public ListaSimple(){

    }

    public void insertaInicio(T dato){
        Nodo<T> n = new Nodo<>();
        n.setInfo(dato);
        n.setSig(inicio);
        inicio = n;
    }

    public void insertaFin(T dato){
        Nodo<T> n = new Nodo<>();
        Nodo<T> r = new Nodo<>();

        n.setInfo(dato);
        if(inicio == null){
//            n.setSig(inicio);
//            inicio = n;
            insertaInicio(dato);
        }else{
            r = inicio;
            while (r.getSig() != null) {
                r = r.getSig();
            }
            r.setSig(n);
            n.setSig(null);
        }
    }

    public T eliminarInicio(){
        if (inicio == null) {
            System.out.println("Lista vacía!");
            return null;
        }else{
            T dato = inicio.getInfo();
            inicio = inicio.getSig();
            return dato;
        }
    }

    public T eliminarFin(){
        Nodo<T> r;
        Nodo<T> a;
        T dato;
        if (inicio == null) {
            System.out.print("Lista vacia");
            return null;

        }else if (inicio.getSig() == null) {
//            dato = inicio.getInfo();
//            inicio = null;
//            return dato;
            dato = eliminarInicio();
            return dato;
        }else{
            r = inicio;
            a = r;
            while (r.getSig() != null) {
                a = r;
                r = r.getSig();
            }
            a.setSig(null);
            return r.getInfo();
        }
    }

    public String imprimir(){
        Nodo r;
        StringBuilder cadena = new StringBuilder();
        if (inicio != null){
            r = inicio;
            while (r != null) {
                cadena.append(r.getInfo() + " ");
                r = r.getSig();
            }
        } else {
            System.out.println("Lista vacia");
        }

        return cadena.toString();
    }

    public int cantidadNodos(){
        Nodo<T> r = inicio;
        int contador = 0;
        if (inicio == null) {
            return 0;
        }else{
            while (r != null) {
                r = r.getSig();
                contador++;
            }
            return contador;
        }
    }


    public String mostrarRecursivo(Nodo<T> x) {
        if (x == null) {
            return "";
        } else {
            return x.getInfo() + " " + mostrarRecursivo(x.getSig());
        }
    }

    public String mostrarR(){return mostrarRecursivo(inicio);}


    public T eliminaX(T x) {
        if (inicio == null) {
            System.out.println("Lista vacia");
            return null;
        }

        // Si el nodo a eliminar está en el inicio
        if (x == inicio.getInfo()) {
            return eliminarInicio();
        }

        // Buscar el nodo que contiene el valor
        Nodo<T> NodoActual = inicio;
        Nodo<T> NodoAnterior = null;

        while (NodoActual != null && !(x == NodoActual.getInfo())) {
            NodoAnterior = NodoActual;
            NodoActual = NodoActual.getSig();
        }

        if (NodoActual == null) {
            System.out.println("El dato no existe");
            return null;
        }

        // Eliminar el nodo encontrado
        NodoAnterior.setSig(NodoActual.getSig());
        return NodoActual.getInfo();
    }

    public int buscar(T x) {
        Nodo<T> NodoActual = inicio;
        int posicion = 0;

        while (NodoActual != null) {
            if (NodoActual.getInfo() == x) {
                return posicion;
            }
            NodoActual = NodoActual.getSig();
            posicion++;
        }

        return -1; // Elemento no encontrado
    }


    public T eliminaPosicion(int posicion) {
        if (inicio == null) {
            System.out.println("Lista vacia");
            return null;
        }

        if (posicion == 0) {
            return eliminarInicio();
        }

        Nodo<T> NodoActual = inicio;
        Nodo<T> NodoAnterior = null;
        int contador = 0;

        while (NodoActual != null && contador < posicion) {
            NodoAnterior = NodoActual;
            NodoActual = NodoActual.getSig();
            contador++;
        }

        if (NodoActual == null) {
            System.out.println("La posicion no existe");
            return null;
        }

        NodoAnterior.setSig(NodoActual.getSig());
        return NodoActual.getInfo();
    }

    public void ordenarLista() {
        if (inicio == null || inicio.getSig() == null) {
            return; // Lista vacia o un solo dato
        }

        boolean cambios;
        do {
            Nodo<T> actual = inicio;
            Nodo<T> siguiente = inicio.getSig();
            Nodo<T> anterior = null;
            cambios = false;

            while (siguiente != null) {
                Comparable<T> actualInfo = (Comparable<T>) actual.getInfo();
                T siguienteInfo = siguiente.getInfo();

                // Comparar y cambiar
                if (actualInfo.compareTo(siguienteInfo) > 0) {
                    // Intercambiar nodos
                    if (anterior != null) {
                        anterior.setSig(siguiente);
                    } else {
                        inicio = siguiente; // Cambia el inicio de la lista
                    }

                    actual.setSig(siguiente.getSig());
                    siguiente.setSig(actual);

                    // Actualizar referencias
                    anterior = siguiente;
                    siguiente = actual.getSig();
                    cambios = true; // Hubo cambio
                } else {
                    anterior = actual;
                    actual = siguiente;
                    siguiente = siguiente.getSig();
                }
            }
        } while (cambios);
    }



    public void insertaEnPosicion(T dato, int posicion) {
        Nodo<T> nuevo = new Nodo<>();
        nuevo.setInfo(dato);

        if (posicion == 0) {
            insertaInicio(dato);
            return;
        }

        Nodo<T> actual = inicio;
        int contador = 0;

        while (actual != null && contador < posicion - 1) {
            actual = actual.getSig();
            contador++;
        }

        if (actual == null) {
            System.out.println("La posicion no existe");
            return;
        }

        nuevo.setSig(actual.getSig());
        actual.setSig(nuevo);
    }




}
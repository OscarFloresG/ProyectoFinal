package org.example;

public class Main {
    public static void main(String[] args) {
        System.out.println("Hello world!");
        //String areglo
        GrafoDirigidoAciclico grafo = new GrafoDirigidoAciclico(5);
        boolean resultado = false;
        //grafo.insertarArista(B,E);
        grafo.insertarArista(3,7);
        grafo.insertarArista(5,6);
        grafo.insertarArista(0,4);
        System.out.println(grafo.topologicalSort());
        System.out.println(grafo.mostrarEstructura());
    }
}
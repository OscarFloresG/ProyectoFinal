package org.example;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Random;

public class GrafoDirigidoAciclico<T> implements Serializable {

    private int[][] matrizDeAdyacencia;
    private HashMap<Integer, ListaSimple<T>> listaDeAdyacencia = null;
    private int numeroDeNodos;
    private T[] vertices;
    private boolean esDeEnteros;
    private int numeroAristas = 0;


    public GrafoDirigidoAciclico(int n) {
        this.esDeEnteros = true;
        this.numeroDeNodos = n;
        this.matrizDeAdyacencia = new int[n][n];
        this.listaDeAdyacencia = new HashMap<>();
        this.numeroAristas = 0;
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                this.matrizDeAdyacencia[i][j] = 0;
            }
        }
        for (int i = 0; i < n; i++) {
            listaDeAdyacencia.put(i, new ListaSimple<>());
        }

        this.vertices = (T[]) new Object[n];

        for (int i = 0; i < n; i++) {
            vertices[i] = (T) Integer.valueOf(i);
        }

    }

    public GrafoDirigidoAciclico() {
        this.esDeEnteros = true;
        numeroDeNodos = 4;
        matrizDeAdyacencia = new int[numeroDeNodos][numeroDeNodos];
        this.vertices = (T[]) new Object[numeroDeNodos];
        this.numeroAristas = 0;

        for (int i = 0; i < numeroDeNodos; i++) {
            int aleatorio = new Random().nextInt(200);
            vertices[i] = (T) Integer.valueOf(aleatorio);
        }

        this.listaDeAdyacencia = new HashMap<>();
        for (int i = 0; i < numeroDeNodos; i++) {
            for (int j = 0; j < numeroDeNodos; j++) {
                this.matrizDeAdyacencia[i][j] = 0;
            }
        }
        for (int i = 0; i < numeroDeNodos; i++) {
            listaDeAdyacencia.put(i, new ListaSimple<>());
        }

    }

    public GrafoDirigidoAciclico(T[] vertices) {
        this.esDeEnteros = false;
        this.numeroDeNodos = vertices.length;
        this.matrizDeAdyacencia = new int[numeroDeNodos][numeroDeNodos];
        this.listaDeAdyacencia = new HashMap<>();
        this.numeroAristas = 0;

        for (int i = 0; i < numeroDeNodos; i++) {
            for (int j = 0; j < numeroDeNodos; j++) {
                this.matrizDeAdyacencia[i][j] = 0;
            }
        }

        for (int i = 0; i < numeroDeNodos; i++) {
            listaDeAdyacencia.put(i, new ListaSimple<>());
        }

        this.vertices = (T[]) new Object[numeroDeNodos];
        for (int i = 0; i < numeroDeNodos; i++) {
            this.vertices[i] = vertices[i];
        }
    }

    public boolean insertarArista(T origen, T destino) {
        int i = obtenerIndice(origen);
        int j = obtenerIndice(destino);

        if (i == -1 || j == -1) {
            System.out.println("Indice invalido: el origen o destino no existen en el grafo.");
            return false;
        }

        if (i == j) {
            System.out.println("No se permiten bucles");
            return false;
        }

        if (tieneCiclos(origen, destino)) {
            System.out.println("No se puede agregar la arista " + origen + " y " + destino);
            return false;
        }
        if (tieneCiclos(destino, origen)) {
            System.out.println("No se puede agregar la arista " + origen + " y " + destino);
            return false;
        }
        matrizDeAdyacencia[i][j] = 1;
        ListaSimple<T> conexion = listaDeAdyacencia.get(i);
        conexion.insertaFin(destino);
        listaDeAdyacencia.put(i, conexion);

        return true;
    }

    private int obtenerIndice(T vertice) {
        for (int k = 0; k < vertices.length; k++) {
            if (vertices[k].equals(vertice)) {
                return k;
            }
        }
        return -1;
    }

    public boolean tieneCiclos(T origen, T destino) {
        int i = obtenerIndice(origen);
        int j = obtenerIndice(destino);
        if (i == -1 || j == -1) {
            System.out.println("Uno o ambos vértices no existen en el grafo.");
            return false;
        }
        return conectado(origen, destino);
    }

    public void eliminarAristas() {
        for (int i = 0; i < numeroDeNodos; i++) {
            listaDeAdyacencia.put(i, new ListaSimple<>());
            for (int j = 0; j < numeroDeNodos; j++) {
                matrizDeAdyacencia[i][j] = 0;
            }
        }
    }

    public String obtenerListaAdyacencia() {
        StringBuilder resultado = new StringBuilder();

        listaDeAdyacencia.forEach((indice, conexiones) -> {
            T vertice = vertices[indice];
            resultado.append(vertice).append(": ").append(conexiones.imprimir()).append("\n");
        });

        return resultado.toString();
    }

    public String mostrarEstructura() {
        StringBuilder sb = new StringBuilder();
        sb.append("     ");
        for (T vertice : vertices) {
            sb.append(vertice).append("   ");
        }
        sb.append("\n");
        for (int i = 0; i < numeroDeNodos; i++) {
            sb.append(vertices[i]).append("   ");
            for (int j = 0; j < numeroDeNodos; j++) {
                sb.append(matrizDeAdyacencia[i][j]).append("   ");
            }
            sb.append("\n");
        }
        return sb.toString();
    }

    public int gradoDeEntrada(T vertice) {
        int i = obtenerIndice(vertice);
        if (i == -1) {
            System.out.println("Vertice no valido: " + vertice);
            return -1;
        }
        int gradoDeEntrada = 0;
        for (int j = 0; j < numeroDeNodos; j++) {
            if (matrizDeAdyacencia[j][i] == 1) {
                gradoDeEntrada++;
            }
        }
        return gradoDeEntrada;
    }

    public int gradoDeSalida(T vertice) {
        int i = obtenerIndice(vertice);
        if (i == -1) {
            System.out.println("Vertice no valido: " + vertice);
            return -1;
        }
        int gradoDeSalida = 0;
        for (int j = 0; j < numeroDeNodos; j++) {
            if (matrizDeAdyacencia[i][j] == 1) {
                gradoDeSalida++;
            }
        }
        return gradoDeSalida;
    }

    public int cuantasAristasHay() {
        int aristas = 0;
        for (int i = 0; i < numeroDeNodos; i++) {
            for (int j = 0; j < numeroDeNodos; j++) {
                if (matrizDeAdyacencia[i][j] == 1) {
                    aristas++;
                }
            }
        }
        this.numeroAristas = aristas;
        return aristas;
    }

    public boolean adyacente(T origen, T destino) {
        int indiceOrigen = obtenerIndice(origen);
        int indiceDestino = obtenerIndice(destino);
        if (indiceOrigen == -1 || indiceDestino == -1) {
            System.out.println("Vertices invalidos: " + origen + " o " + destino);
            return false;
        }
        return matrizDeAdyacencia[indiceOrigen][indiceDestino] == 1;
    }

    public boolean conectado(T inicio, T destino) {
        boolean[] visitados = new boolean[numeroDeNodos];
        ColaSimple<T> cola = new ColaSimple<>();

        int indiceInicio = obtenerIndice(inicio);
        int indiceDestino = obtenerIndice(destino);

        if (indiceInicio == -1 || indiceDestino == -1) {
            System.out.println("Vertices invalidos: " + inicio + " o " + destino);
            return false;
        }
        cola.insertar(inicio);
        visitados[indiceInicio] = true;
        while (!cola.esVacio()) {
            T nodoActual = cola.eliminar();
            int indiceActual = obtenerIndice(nodoActual);

            if (indiceActual == indiceDestino) {
                return true;
            }

            for (int adyacente = 0; adyacente < numeroDeNodos; adyacente++) {
                if (matrizDeAdyacencia[indiceActual][adyacente] == 1 && !visitados[adyacente]) {
                    cola.insertar(vertices[adyacente]);
                    visitados[adyacente] = true;
                }
            }
        }
        return false;
    }

    public String topologicalSort() {
        StringBuilder ordenTopologico = new StringBuilder();

        int[] gradoDeEntrada = new int[numeroDeNodos];
        for (int i = 0; i < numeroDeNodos; i++) {
            gradoDeEntrada[i] = gradoDeEntrada(vertices[i]);
        }
        for (int k = 0; k < numeroDeNodos; k++) {
            int nodoConPrioridad = -1;
            for (int i = 0; i < numeroDeNodos; i++) {
                if (gradoDeEntrada[i] == 0) {
                    nodoConPrioridad = i;
                    i = numeroDeNodos + 1;
                }
            }
            if (!esDeEnteros) {
                //ordenTopologico.append((char) (nodoConPrioridad + 65)).append("-");
                ordenTopologico.append(vertices[nodoConPrioridad]).append("-");
                gradoDeEntrada[nodoConPrioridad] = -1;
                for (int j = 0; j < numeroDeNodos; j++) {
                    if (matrizDeAdyacencia[nodoConPrioridad][j] == 1) {
                        gradoDeEntrada[j]--;
                    }
                }
            } else {
                ordenTopologico.append(vertices[nodoConPrioridad]).append("-");
                gradoDeEntrada[nodoConPrioridad] = -1;
                for (int j = 0; j < numeroDeNodos; j++) {
                    if (matrizDeAdyacencia[nodoConPrioridad][j] == 1) {
                        gradoDeEntrada[j]--;
                    }
                }
            }
        }
        ordenTopologico.deleteCharAt(ordenTopologico.length() - 1);
        return ordenTopologico.toString();
    }

    public boolean getEsDeEnteros() {
        return esDeEnteros;
    }

    public int[][] getMatrizDeAdyacencia() {
        return matrizDeAdyacencia;
    }

    public T[] getVertices() {
        return vertices;
    }

}

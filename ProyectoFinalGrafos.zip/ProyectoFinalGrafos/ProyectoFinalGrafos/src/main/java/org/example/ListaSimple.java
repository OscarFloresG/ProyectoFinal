package org.example;

import java.io.Serializable;

public class ListaSimple <T> implements Serializable {

    private Nodo<T> inicio;

    public ListaSimple(){

    }

    public void insertaInicio(T dato){
        Nodo<T> n = new Nodo<>();
        n.setInfo(dato);
        n.setSig(inicio);
        inicio = n;
    }

    public void insertaFin(T dato){
        Nodo<T> n = new Nodo<>();
        Nodo<T> r = new Nodo<>();

        n.setInfo(dato);
        if(inicio == null){
//            n.setSig(inicio);
//            inicio = n;
            insertaInicio(dato);
        }else{
            r = inicio;
            while (r.getSig() != null) {
                r = r.getSig();
            }
            r.setSig(n);
            n.setSig(null);
        }
    }

    public T eliminarInicio(){
        if (inicio == null) {
            System.out.println("Lista vacía!");
            return null;
        }else{
            T dato = inicio.getInfo();
            inicio = inicio.getSig();
            return dato;
        }
    }

    public T eliminarFin(){
        Nodo<T> r;
        Nodo<T> a;
        T dato;
        if (inicio == null) {
            System.out.print("Lista vacia");
            return null;

        }else if (inicio.getSig() == null) {
//            dato = inicio.getInfo();
//            inicio = null;
//            return dato;
            dato = eliminarInicio();
            return dato;
        }else{
            r = inicio;
            a = r;
            while (r.getSig() != null) {
                a = r;
                r = r.getSig();
            }
            a.setSig(null);
            return r.getInfo();
        }
    }

    public String imprimir(){
        Nodo r;
        StringBuilder cadena = new StringBuilder();
        if (inicio != null){
            r = inicio;
            while (r != null) {
                cadena.append(" -> " + r.getInfo() + " ");
                r = r.getSig();
            }
        } else {
            //System.out.println("Lista vacia");
        }

        return cadena.toString();
    }


}
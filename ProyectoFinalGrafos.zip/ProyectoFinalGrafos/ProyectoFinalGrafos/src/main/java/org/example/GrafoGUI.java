package org.example;

import com.mxgraph.swing.mxGraphComponent;
import com.mxgraph.view.mxGraph;
import javax.swing.*;
import java.awt.*;
import java.util.HashMap;

public class GrafoGUI<T> extends JPanel {
    private GrafoDirigidoAciclico<T> grafo;
    private mxGraph graph;
    private Object parent;
    private HashMap<T, Object> verticesGUI;

    public GrafoGUI(GrafoDirigidoAciclico<T> grafo, T[] vertices, int[][] matrizAdyacencia) {
        this.grafo = grafo;
        this.graph = new mxGraph();
        this.parent = graph.getDefaultParent();
        this.verticesGUI = new HashMap<>();

        setLayout(new BorderLayout());

        mxGraphComponent graphComponent = new mxGraphComponent(graph);
        add(graphComponent, BorderLayout.CENTER);

        graph.getModel().beginUpdate();
        try {
            graph.setAllowDanglingEdges(false);
            graph.setCellsDisconnectable(false);
        } finally {
            graph.getModel().endUpdate();
        }
        cargarGrafoDesdeMatriz(vertices, matrizAdyacencia);
    }

    private void cargarGrafoDesdeMatriz(T[] vertices, int[][] matrizAdyacencia) {
        graph.getModel().beginUpdate();
        try {
            verticesGUI.clear();
        } finally {
            graph.getModel().endUpdate();
        }

        for (int i = 0; i < vertices.length; i++) {
            agregarVertice(vertices[i]);
        }

        for (int i = 0; i < matrizAdyacencia.length; i++) {
            for (int j = 0; j < matrizAdyacencia[i].length; j++) {
                if (matrizAdyacencia[i][j] == 1) {
                    T origen = vertices[i];
                    T destino = vertices[j];
                    agregarArista(origen, destino);
                }
            }
        }
    }

    private void agregarVertice(T vertice) {
        graph.getModel().beginUpdate();
        try {
            int index = verticesGUI.size();
            int fila = index / 5;
            int columna = index % 5;

            int x = 50 + (columna * 100);
            int y = 50 + (fila * 100);

            Object vertex = graph.insertVertex(parent, null, vertice, x, y, 50, 50);
            graph.getModel().setStyle(vertex, "shape=ellipse;fillColor=#0000FF;strokeColor=#000000;fontColor=#FFFFFF;");
            verticesGUI.put(vertice, vertex);
        } finally {
            graph.getModel().endUpdate();
        }
    }

    private void agregarArista(T origen, T destino) {
        Object origenGUI = verticesGUI.get(origen);
        Object destinoGUI = verticesGUI.get(destino);
        if (origenGUI != null && destinoGUI != null) {
            graph.getModel().beginUpdate();
            try {
                graph.insertEdge(parent, null, "", origenGUI, destinoGUI);
            } finally {
                graph.getModel().endUpdate();
            }
        }
    }

    public void actualizarGrafo(T[] vertices, int[][] matrizAdyacencia) {
        graph.getModel().beginUpdate();
        try {
            verticesGUI.clear();
            graph.removeCells(graph.getChildVertices(parent));

            for (int i = 0; i < vertices.length; i++) {
                agregarVertice(vertices[i]);
            }

            for (int i = 0; i < matrizAdyacencia.length; i++) {
                for (int j = 0; j < matrizAdyacencia[i].length; j++) {
                    if (matrizAdyacencia[i][j] == 1) {
                        T origen = vertices[i];
                        T destino = vertices[j];
                        agregarArista(origen, destino);
                    }
                }
            }
        } finally {
            graph.getModel().endUpdate();
        }
    }
}
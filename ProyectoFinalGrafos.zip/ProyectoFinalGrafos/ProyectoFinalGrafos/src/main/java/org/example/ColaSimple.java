package org.example;

import java.util.Arrays;

public class ColaSimple<T> {

    public int inicio;
    public int fin;
    public int max;
    public T[] cola_Simple;

    public ColaSimple() {
        inicio = -1;
        fin = -1;
        max = 5;
        cola_Simple = (T[]) new Object[max];
    }


    public void insertar(T dato) {
        if (fin < max - 1) {
            fin = fin + 1;
            cola_Simple[fin] = dato;
            if (inicio == -1) {
                inicio = 0;
            }
        } else {
            System.out.println("Desbordamiento");
        }
    }

    public T eliminar() {
        T dato = null;
        if (inicio != -1) {
            dato = cola_Simple[inicio];
            if (inicio == fin) {
                inicio = -1;
                fin = -1;
            } else {
                inicio = inicio + 1;
            }
        } else {
            System.out.println("Subdesbordamiento");
        }
        return dato;
    }

    public boolean esVacio() {
        return inicio == -1;
    }

    @Override
    public String toString() {
        return "ColaSimple{" +
                "cola_Simple=" + Arrays.toString(Arrays.copyOfRange(cola_Simple, inicio, fin + 1)) +
                '}';
    }
}
